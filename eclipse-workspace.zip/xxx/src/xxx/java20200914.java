package xxx;

public class java20200914 {
	public static void main(String[] args) {
		int a=10;
		int b=12;
		b+=a;
		System.out.print(b);
	}

}
