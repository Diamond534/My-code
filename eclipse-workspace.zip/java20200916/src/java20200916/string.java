package java20200916;

public class string {
	public static void main(String[] args) {
//		String str="123456abc";//�����ַ���
//		String str1=str+"f";
//		System.out.print(str1);//123456abcf
//		String str=new String("123456");
		
//		byte[] bs= {1,2,3,4,5};
//		String str=new String(bs);
//		System.out.print(str);//����
		
		
//		byte[]bs= {1,2,3,4,5};
//		String str=new String
//		
		
//		StringBuffer sb=new StringB
		
		
				
		
		
	}

}
