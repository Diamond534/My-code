package java20200929�ӿ�;

public class Myclass<T> {  //����****
	public int add(T op1,T op2) {
		return (Integer)op1+(Integer)op2;
	}

}
