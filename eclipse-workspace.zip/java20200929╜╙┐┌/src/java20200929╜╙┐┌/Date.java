package java20200929�ӿ�;

public class Date {
	public static void main(String[] args) {
		Date date=new Date();
		System.out.print(date);
	}

}
