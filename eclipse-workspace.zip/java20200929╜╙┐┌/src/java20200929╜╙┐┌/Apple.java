package java20200929�ӿ�;

public class Apple implements IFrunit{  //ƻ����

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.print("The apple is eaten after it is peeled");
		
	}

	@Override
	public void pick() {
		// TODO Auto-generated method stub
		System.out.print("Apples need to be picked from apple trees");
	}///ƻ����
	
	

}
