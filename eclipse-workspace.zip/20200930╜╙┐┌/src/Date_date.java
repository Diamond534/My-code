import java.sql.Date;
import java.text.SimpleDateFormat;
/*
 * �������ڵ���
 * */
public class Date_date {
	public static void main(String[] args) {
		/*
		Date date=new Date(0);
		SimpleDateFormat format =new SimpleDateFormat("yyyy��MM��dd�� hh:mm:ss"); //�򵥵����ڸ�ʽ
		System.out.print(date);
		System.out.print("\n");
		
		System.out.print(format.format(date));
		*/
		
		/*
		Calendar cal=Calendar.getInstance();
		System.out.print(cal.get(Calendar.YEAR));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.MONTH)+1);
		System.out.print("\n");
		System.out.print(cal.get(Calendar.DATE));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.HOUR));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.MINUTE));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.SECOND));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.AM_PM));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.DAY_OF_MONTH));
		System.out.print("\n");
		System.out.print(cal.get(Calendar.DAY_OF_YEAR));
		System.out.print("\n");
		*/
		
		/*
		long date = 0;
		Date date1=new Date(date);
		int s=0;
		for(long i=0;i<=900000000;i++) {
			s+=i;
		}
		System.out.print(s+"\n");
		Date date2 =new Date(0);
		System.out.print((date2.getTime()-date1.getTime())/1000);//��
		System.out.print(date2.getTime()-date1.getTime());//����
		*/
		
		/*
		Math.random();
		System.out.print(Math.random());//0~1
		System.out.print("\n");
		System.out.print((int)(Math.random()*100));//0~100 //ȡ��
		System.out.print("\n");
		System.out.print((int)(Math.random()*100/10));//0~10
		System.out.print("\n");
		System.out.print((int)(Math.random()*10000));//0~10000
		System.out.print("\n");
		System.out.print("\n");
		System.out.print("\n");
		*/
	}

}
