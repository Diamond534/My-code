package java�̳�;

public class penguin {//�����
	private String name;
	private int id;
	public penguin(String myName, int myid) {
		name=myName;
		id=myid;
	}
	public void eat() {
		System.out.print(name+"���ڳ�");
	}
	

}
