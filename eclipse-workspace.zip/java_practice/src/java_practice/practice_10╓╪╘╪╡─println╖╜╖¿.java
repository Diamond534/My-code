package java_practice;

public class practice_10���ص�println���� {
	public static void main(String[] args) {
		myPrint(99);
		myPrint('a');
		myPrint('A'+01);
	}
	public static void myPrint(byte num) {
		System.out.println("byteֵ"+num);
	}
	public static void myPrint(short num) {
		System.out.println("shortֵ"+num);
	}
	public static void myPrint(double num) {
		System.out.println("doubleֵ"+num);
	}
	public static void myPrint(long num) {
		System.out.println("longֵ"+num);
	}
	public static void myPrint(int num) {
		System.out.println("intֵ"+num);
	}
	public static void myPrint(float num) {
		System.out.println("floatֵ"+num);
	}
	public static void myPrint(char num) {
		System.out.println("charֵ"+num);
	}

}
