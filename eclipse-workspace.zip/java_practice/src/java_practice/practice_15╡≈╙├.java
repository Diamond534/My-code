package java_practice;

public class practice_15���� {
	public static void main(String[] args) {
        int [] array={
          1,2,3,4,
        };
        printArray(array);
	}

        public static void printArray(int[] array) {
            for (int i = 0; i < array.length; i++) {
                System.out.println(array[i]);
            }

        }
    

}
