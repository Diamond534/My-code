package java20200923;

public class n extends Math {

}
