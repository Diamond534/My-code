package java20200923;

public class Rice extends Food {//�׷�

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.print("Rice is eaten with chopsticks");
		
	}
	
	

}
