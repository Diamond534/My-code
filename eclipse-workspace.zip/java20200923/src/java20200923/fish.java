package java20200923;

public class fish  extends Animal{
	public fish(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void run() {
		System.out.println("Fish swim in the water");
	}

}
