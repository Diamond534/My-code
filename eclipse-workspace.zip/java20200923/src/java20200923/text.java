package java20200923;

import java.awt.Point;

public class text {
	public static void main(String[] args) {
		Point p1;
		point p2;
		p1=new Point();
		p1=new Point();
		p1.setPoint(10, 10);
		p1.setPoint(10, 0);
		System.out.print(p1.getDistance(p1, p2));
		
		//�� Math
		Object m=new Object();
	}

}
